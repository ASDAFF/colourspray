<?
    $arDefaultParams = array(
        "MAIN_ELEMENTS_COUNT" => "5"
    );
    
    $arParams = array_merge($arDefaultParams, $arParams);
?>