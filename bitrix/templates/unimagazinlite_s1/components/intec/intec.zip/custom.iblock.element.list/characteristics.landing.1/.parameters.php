<?
    $arTemplateParameters = array(
        "MAIN_ELEMENTS_COUNT" => array(
            "NAME" => GetMessage("MAIN_ELEMENTS_COUNT"),
            "TYPE" => "STRING"
        )
    );
?>