<?
    $arDefaultParams = array(
        "MAIN_ELEMENTS_COUNT" => "5",
        "SHOW_ALL_ELEMENTS" => "N"
    );
    
    $arParams = array_merge($arDefaultParams, $arParams);
?>