<?
    $arTemplateParameters = array(
        "USE_LINK_TO_ELEMENTS" => array(
            "NAME" => GetMessage("USE_LINK_TO_ELEMENTS"),
            "TYPE" => "CHECKBOX",
            "DEFAULT" => "N"
        ),
        "LINK_TO_ELEMENTS" => array(
            "NAME" => GetMessage("LINK_TO_ELEMENTS"),
            "TYPE" => "STRING"
        ),
        "PICTURE_BLOCK_HEIGHT" => array(
            "NAME" => GetMessage("PICTURE_BLOCK_HEIGHT"),
            "TYPE" => "STRING",
            "DEFAULT" => "71%"
        )
    )
?>