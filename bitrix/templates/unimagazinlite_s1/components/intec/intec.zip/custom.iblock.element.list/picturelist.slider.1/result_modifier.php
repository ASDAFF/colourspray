<?if (!defined('B_PROLOG_INCLUDED') && B_PROLOG_INCLUDED !== true) die();?>
<?
    $arDefaultParams = array(
        'PICTURE_BLOCK_HEIGHT' => '100%'
    );
    
    $arParams = array_merge($arDefaultParams, $arParams);
?>