<?
    $arDefaultParams = array(
        "USE_LINK_TO_ELEMENTS" => "N",
        "PICTURE_BLOCK_HEIGHT" => "100%"
    );
    
    $arParams = array_merge($arDefaultParams, $arParams);
?>