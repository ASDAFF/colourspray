<?    
    $arTemplateParameters = array(
        "USE_LINK_TO_ELEMENTS" => array(
            "NAME" => GetMessage("USE_LINK_TO_ELEMENTS"),
            "TYPE" => "CHECKBOX",
            "DEFAULT" => "N"
        ),
        "PICTURE_BLOCK_HEIGHT" => array(
            "NAME" => GetMessage("ELEMENTS_HEIGHT"),
            "TYPE" => "STRING",
            "DEFAULT" => "100%"
        )
    );
?>