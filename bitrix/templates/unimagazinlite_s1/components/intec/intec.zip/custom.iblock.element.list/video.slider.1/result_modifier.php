<?
    $arDefaultParams = array(
        "SLIDER_ID" => "slider",
    );
    
    $arParams = array_merge($arDefaultParams, $arParams);
?>