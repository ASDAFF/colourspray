<?
    $arTemplateParameters = array(
        "SLIDER_ID" => array(
            "NAME" => GetMessage("SLIDER_ID"),
            "TYPE" => "STRING",
            "DEFAULT" => "slider"
        )
    )
?>