<?
    $arTemplateParameters = array(
        "PICTURES" => array(
            "PARENT" => "BASE",
            "NAME" => GetMessage("PICTURES"),
            "TYPE" => "STRING",
            "MULTIPLE" => "Y"
        )
    )
?>