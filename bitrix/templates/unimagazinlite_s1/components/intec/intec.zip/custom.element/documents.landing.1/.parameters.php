<?
    $arTemplateParameters = array(
        "FILES" => array(
            "PARENT" => "BASE",
            "NAME" => GetMessage("FILES"),
            "TYPE" => "STRING",
            "MULTIPLE" => "Y"
        )
    )
?>