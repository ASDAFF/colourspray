<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();?>
<?$this->setFrameMode(true)?>
<a href="<?=$arResult['DETAIL_PAGE_URL']?>" class="uni-image" style="display: block; width: 100%; height: 100%;">
    <div class="uni-aligner-vertical"></div>
    <img src="<?=$arResult['PICTURE']?>" />
</a>