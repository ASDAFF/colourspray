<?
    $arDefaultParams = array(
        "DISPLAY_NOTIFICATION" => "Y",
        "DISPLAY_NOTIFICATION_BUTTON" => "Y"
    );
    
    $arParams = array_merge($arDefaultParams, $arParams);
?>