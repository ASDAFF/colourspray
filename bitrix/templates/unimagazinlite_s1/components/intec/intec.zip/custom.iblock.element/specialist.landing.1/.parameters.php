<?
    $arTemplateParameters = array(
        "DISPLAY_NOTIFICATION" => array(
            "PARENT" => "VISUAL",
            "NAME" => GetMessage("DISPLAY_NOTIFICATION"),
            "TYPE" => "CHECKBOX",
            "DEFAULT" => "Y"
        ),
        "DISPLAY_NOTIFICATION_BUTTON" => array(
            "PARENT" => "VISUAL",
            "NAME" => GetMessage("DISPLAY_NOTIFICATION_BUTTON"),
            "TYPE" => "CHECKBOX",
            "DEFAULT" => "Y"
        ),
        "NOTIFICATION_BUTTON_ID" => array(
            "NAME" => GetMessage("NOTIFICATION_BUTTON_ID"),
            "TYPE" => "STRING"
        )
    )
?>